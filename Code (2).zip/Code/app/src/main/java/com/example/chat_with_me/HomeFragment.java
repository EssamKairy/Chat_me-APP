package com.example.chat_with_me;


import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Objects;


/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFragment extends Fragment {

    private FirebaseAuth firebaseAuth;

    public HomeFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        //init
        firebaseAuth = FirebaseAuth.getInstance();

        return view;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        setHasOptionsMenu(true);//to show menu
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_main, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        //get item id
        int id = item.getItemId();

        if (id == R.id.action_layout) {
            test();
            firebaseAuth.signOut();
            checkUserState();
        }
        return super.onOptionsItemSelected(item);
    }

    private void test() {
        FirebaseUser user = firebaseAuth.getCurrentUser();
        //Get user email and uid from auth
        String email = user.getEmail();
        String uid = user.getUid();
        //when user is registered store user info in firebase realtime database too
        //Using  HashMap
        String time = String.valueOf(System.currentTimeMillis());
        HashMap<Object, String> map = new HashMap<>();
        //put info in hash map
        map.put(getString(R.string.user_mail), email);
        map.put(getString(R.string.uid), uid);
        map.put(getString(R.string.u_name), "");
        map.put(getString(R.string.u_stat), time);
        map.put(getString(R.string.typing_to), "noOne");
        map.put(getString(R.string.phone_), "");
        map.put(getString(R.string.img_), "");
        map.put(getString(R.string.cover_), "");

        //database
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        //path to store user data
        DatabaseReference reference = database.getReference(getString(R.string.users));
        //put data within hash map in database
        reference.child(uid).setValue(map);
    }

    private void checkUserState() {
        FirebaseUser user = firebaseAuth.getCurrentUser();
        if (user != null) {
            //user if signed in stay here
            Toast.makeText(getActivity(), "Signed In", Toast.LENGTH_SHORT).show();
        } else {
            //user not signed in, go to main activity
            startActivity(new Intent(getActivity(), MainActivity.class));
            Objects.requireNonNull(getActivity()).finish();
        }
    }

}
