package com.example.chat_with_me.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.chat_with_me.ChatActivity;
import com.example.chat_with_me.R;
import com.example.chat_with_me.models.ModelUser;
import com.squareup.picasso.Picasso;

import java.util.List;

public class AdapterUsers extends RecyclerView.Adapter<AdapterUsers.MyHolder>{

    private Context context;
    private List<ModelUser> modelUsers;

    public AdapterUsers(Context context, List<ModelUser> modelUsers) {
        this.context = context;
        this.modelUsers = modelUsers;
    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.row_users, parent, false);


        return new MyHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, int position) {

        //get data
        final String hisUID = modelUsers.get(position).getUid();
        String userImage = modelUsers.get(position).getImage();
        String userName = modelUsers.get(position).getName();
        final String userEmail = modelUsers.get(position).getEmail();

        //set data
        holder.mName.setText(userName);
        holder.mEmail.setText(userEmail);
        try {
            Picasso.get().load(userImage).
                    placeholder(R.drawable.ic_default_img)
                    .into(holder.mAvatar);
        }
        catch (Exception ignored){

        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(context, ChatActivity.class);
                intent.putExtra("hisUid", hisUID);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return modelUsers.size();
    }


    //view holder
    class MyHolder extends RecyclerView.ViewHolder{

        ImageView mAvatar;
        TextView mName, mEmail;

        public MyHolder(@NonNull View itemView) {
            super(itemView);
            mAvatar = itemView.findViewById(R.id.avatarIV);
            mName = itemView.findViewById(R.id.av_name);
            mEmail = itemView.findViewById(R.id.av_email);
        }
    }
}
