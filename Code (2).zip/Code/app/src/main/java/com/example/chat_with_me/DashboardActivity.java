package com.example.chat_with_me;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class DashboardActivity extends AppCompatActivity {

    FirebaseAuth firebaseAuth;
    ActionBar actionBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashborad);

        actionBar = getSupportActionBar();
        assert actionBar != null;
        actionBar.setTitle("Profile");

        //init
        firebaseAuth = FirebaseAuth.getInstance();

        //bottom navigation
        BottomNavigationView navigationView = findViewById(R.id.navigation);
        navigationView.setOnNavigationItemSelectedListener(selectedListener);

        //home fragment transaction, default, on start
        actionBar.setTitle("Profile"); //change action bar title
        HomeFragment home = new HomeFragment();
        FragmentTransaction ftl = getSupportFragmentManager().beginTransaction();
        ftl.replace(R.id.Container, home, "");
        ftl.commit();
    }

    private BottomNavigationView.OnNavigationItemSelectedListener selectedListener =
            new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                    //handle item clicks
                    switch (menuItem.getItemId()){

                        case R.id.nav_profile:
                            //profile fragment transaction
                            //home fragment transaction
                            actionBar.setTitle("Profile"); //change action bar title
                            ProfileFragment profile = new ProfileFragment();
                            FragmentTransaction ftL = getSupportFragmentManager().beginTransaction();
                            ftL.replace(R.id.Container, profile, "");
                            ftL.commit();
                            return true;

                        case R.id.nav_Users:
                            //users fragment transaction
                            //home fragment transaction
                            actionBar.setTitle("Users"); //change action bar title
                            UsersFragment users = new UsersFragment();
                            FragmentTransaction ftl2 = getSupportFragmentManager().beginTransaction();
                            ftl2.replace(R.id.Container, users, "");
                            ftl2.commit();
                            return true;

                        case R.id.nav_home:
                            //users fragment transaction
                            //home fragment transaction
                            actionBar.setTitle("Home"); //change action bar title
                            HomeFragment home = new HomeFragment();
                            FragmentTransaction ftl3 = getSupportFragmentManager().beginTransaction();
                            ftl3.replace(R.id.Container, home, "");
                            ftl3.commit();
                            return true;
                    }
                    return false;
                }
            };

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    private void checkUserState(){
        FirebaseUser user = firebaseAuth.getCurrentUser();
        if(user != null){
            //user if signed in stay here
        }
        else{
            //user not signed in, go to main activity
            startActivity(new Intent(DashboardActivity.this, MainActivity.class));
            finish();
        }
    }

    @Override
    protected void onStart() {
        //check on start of app
        checkUserState();
        super.onStart();
    }


}
