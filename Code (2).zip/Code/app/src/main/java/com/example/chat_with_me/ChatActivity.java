package com.example.chat_with_me;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.format.DateFormat;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.chat_with_me.adapters.AdapterChat;
import com.example.chat_with_me.models.ModelChat;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

public class ChatActivity extends AppCompatActivity {

    //Views
    Toolbar toolbar;
    RecyclerView recyclerView;
    ImageView profileIV;
    TextView nameTV, userstatus;
    EditText messageEt;
    ImageButton sendBtn;

    //firebase auth
    private FirebaseAuth firebaseAuth;

    FirebaseDatabase firebaseDatabase;
    DatabaseReference userDbRef;

    //for checking if user seen msg or not
    ValueEventListener seenListener;
    DatabaseReference userRefForSeen;

    List<ModelChat> chatList;
    AdapterChat adapterChat;


    String hisUid;
    String myUid;
    String hisImage;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        //init views
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setTitle("");
        recyclerView = findViewById(R.id.chat_recyclerView);
        profileIV = findViewById(R.id.profile_IV);
        nameTV = findViewById(R.id.nameTV);
        userstatus = findViewById(R.id.userStatusTV);
        messageEt = findViewById(R.id.messageET);
        sendBtn = findViewById(R.id.sendBtn);


        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setStackFromEnd(true);

        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(linearLayoutManager);

        Intent intent = getIntent();
        hisUid = intent.getStringExtra("hisUid");

        //firebase instance
        firebaseAuth = FirebaseAuth.getInstance();
        firebaseDatabase = FirebaseDatabase.getInstance();
        userDbRef = firebaseDatabase.getReference("Users");

        //search user to get that user's info
        Query userQuery = userDbRef.orderByChild("uid").equalTo(hisUid);
        userQuery.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                //check until required info is received
                for (DataSnapshot ds : dataSnapshot.getChildren()){
                    //get data
                    String name = "" + ds.child("name").getValue();
                    hisImage = "" + ds.child("image").getValue();

                    //typing status
                    String typingStatus = "" + ds.child("typingTo").getValue();

                    if (typingStatus.equals(myUid)){
                        userstatus.setText(getString(R.string.typing));
                    }
                    else{

                        //online status
                        String onlineStatus = ""+ ds.child("onlineStatus").getValue();

                        if (onlineStatus.equals("online")){
                            userstatus.setText(onlineStatus);
                        }
                        else {
                            //convert time
                            Calendar cal = Calendar.getInstance(Locale.ENGLISH);
                            cal.setTimeInMillis(Long.parseLong(onlineStatus));
                            String datetime = DateFormat.format("dd/MM/yyyy hh:mm aa",cal).toString();
                            String status = getString(R.string.lastseen)+""+datetime;
                            userstatus.setText(status);
                        }
                    }

                    //online status
                    String onlineStatus = ""+ ds.child("onlineStatus").getValue();

                    if (onlineStatus.equals("online")){
                        userstatus.setText(onlineStatus);
                    }
                    else {
                        //convert time
                        Calendar cal = Calendar.getInstance(Locale.ENGLISH);
                        cal.setTimeInMillis(Long.parseLong(onlineStatus));
                        String datetime = DateFormat.format("dd/MM/yyyy hh:mm aa",cal).toString();
                        String status = getString(R.string.lastseen)+""+datetime;
                        userstatus.setText(status);
                    }

                    //set data
                    nameTV.setText(name);
                    try {
                        Picasso.get().load(hisImage).
                                placeholder(R.drawable.ic_default_img).
                                into(profileIV);
                    }catch (Exception e){
                        //if error occur
                        Picasso.get().load(R.drawable.ic_default_img).into(profileIV);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        //sendBtn clicked
        sendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //get text
                String msg = messageEt.getText().toString().trim();

                //check if text is not empty
                if (TextUtils.isEmpty(msg)){
                    //text empty
                    Toast.makeText(ChatActivity.this, "Empty message", Toast.LENGTH_SHORT).show();

                }

                else {
                    //text not empty
                    sendMessage(msg);
                }
            }
        });

        messageEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.toString().trim().length() == 0){
                    checkTypingStatus("noOne");
                }
                else {
                    checkTypingStatus(hisUid);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        readMessages();
        seenMessages();
    }

    private void seenMessages() {

        userRefForSeen = FirebaseDatabase.getInstance().getReference("Chats");
        seenListener = userRefForSeen.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren()){
                    ModelChat chat = ds.getValue(ModelChat.class);

                        if (chat.getReceiver().equals(myUid) && chat.getSender().equals(hisUid)){
                            HashMap<String, Object> hasSeenHashMap = new HashMap<>();
                            hasSeenHashMap.put("isSeen", true);
                            ds.getRef().updateChildren(hasSeenHashMap);
                        }




                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void readMessages() {
        chatList = new ArrayList<>();
        DatabaseReference dbRef = FirebaseDatabase.getInstance().getReference("Chats");
        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                chatList.clear();
                for (DataSnapshot ds : dataSnapshot.getChildren()){
                    ModelChat chat = ds.getValue(ModelChat.class);


                        if (chat.getReceiver().equals(myUid) && chat.getSender().equals(hisUid) ||
                                chat.getReceiver().equals(hisUid) && chat.getSender().equals(myUid)){
                            chatList.add(chat);
                        }

                    //adapter
                    adapterChat = new AdapterChat(ChatActivity.this, chatList, hisImage);

                    adapterChat.notifyDataSetChanged();
                    //set adapter to recyclerview
                    recyclerView.setAdapter(adapterChat);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void sendMessage(String msg) {
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference();

        String timestamp = String.valueOf(System.currentTimeMillis());

        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("sender", myUid);
        hashMap.put("receiver", hisUid);
        hashMap.put("message", msg);
        hashMap.put("timestamp", timestamp);
        hashMap.put("isSeen", false);
        reference.child("Chats").push().setValue(hashMap);

        //reset edit text after sending msg
        messageEt.setText("");
    }

    private void checkUserState(){
        FirebaseUser user = firebaseAuth.getCurrentUser();
        if(user != null){
            //user if signed in stay here
            myUid = user.getUid();//current user
        }
        else{
            //user not signed in, go to main activity
            startActivity(new Intent(this, MainActivity.class));
           finish();
        }
    }

    private void checkOnlineStatus(String status){
        DatabaseReference dbRef = FirebaseDatabase.getInstance().getReference().child(myUid);
        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("onlineStatus",status);
        //update status
        dbRef.updateChildren(hashMap);
    }

    private void checkTypingStatus(String typing){
        DatabaseReference dbRef = FirebaseDatabase.getInstance().getReference().child(myUid);
        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("typingTo",typing);
        //update status
        dbRef.updateChildren(hashMap);
    }

    @Override
    protected void onStart() {
        checkUserState();
        checkOnlineStatus("online");
        super.onStart();
    }

    @Override
    protected void onPause() {
        super.onPause();
        String timestamp = String.valueOf(System.currentTimeMillis());
        checkOnlineStatus(timestamp);
        checkTypingStatus("noOne");
        userRefForSeen.removeEventListener(seenListener);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        // hide search view here we don't need it here
        menu.findItem(R.id.action_search).setVisible(false);
        return super.onCreateOptionsMenu(menu);
    }

    private void test(){
        FirebaseUser user = firebaseAuth.getCurrentUser();
        //Get user email and uid from auth
        String email = user.getEmail();
        String uid = user.getUid();
        //when user is registered store user info in firebase realtime database too
        //Using  HashMap
        String time = String.valueOf(System.currentTimeMillis());
        HashMap<Object, String> map = new HashMap<>();
        //put info in hash map
        map.put("email", email);
        map.put("uid", uid);
        map.put("name", "");
        map.put("onlineStatus", time);
        map.put("typingTo", "noOne");
        map.put("phone", "");
        map.put("image", "");
        map.put("cover", "");

        //database
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        //path to store user data
        DatabaseReference reference = database.getReference("Users");
        //put data within hash map in database
        reference.child(uid).setValue(map);
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        //get item id
        int id = item.getItemId();

        if(id == R.id.action_layout){
            test();
            firebaseAuth.signOut();

            checkUserState();
        }
        return super.onOptionsItemSelected(item);
    }
}
